# Exercice 12

Stocker dans une variable la phrase `Je suis content`. Stocker dans une autre variable le genre d'un utilisateur.ice fictif.ve. En fonction du genre, afficher la phrase accordée au féminin si besoin.
