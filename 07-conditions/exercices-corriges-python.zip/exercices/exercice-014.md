# Exercice 14

Stocker dans une variable un âge aléatoire. Afficher soit `Je suis majeur`, soit `Je suis mineur` en fonction de cet âge.
