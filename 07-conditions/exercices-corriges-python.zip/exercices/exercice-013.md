# Exercice 13

Stocker dans une variable un nombre aléatoire en utilisant la fonction `rand()`. Afficher si ce nombre est pair ou impair.
