# Exercice 15

Générer un nombre aléatoire. Afficher `pouet` s'il est divisible par 3, `plouf` s'il est divisible par 5, `pouetplouf` s'il est divisible par 3 et 5. Sinon, afficher le nombre.
