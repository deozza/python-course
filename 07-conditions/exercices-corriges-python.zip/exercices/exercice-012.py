message = 'Je suis content'
genre = 'truc'

if genre == 'femme':
    message += 'e'

print(message)

